//
//  FPhiGraphTransition.h
//  FPhiUCios
//
//  Created by Ruben Leal on 16/5/17.
//  Copyright © 2017 Facephi Biometria S.A. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FPhiGraphTransition : NSObject

@property (nonatomic) NSString *from;

@property (nonatomic) NSString *to;

@end
